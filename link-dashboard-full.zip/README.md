# Link Dashboard (Frontend + Helm)

## What
Simple React dashboard that reads `config.json` from a mounted ConfigMap and displays tiles for quick links.

## Build & Deploy
1. Build frontend image:
   ```bash
   cd frontend
   npm ci
   npm run build
   docker build -t your-registry/link-dashboard-frontend:latest .
   docker push your-registry/link-dashboard-frontend:latest
   ```
2. Update `helm/values.yaml` if needed (image.repository, tag, links, ingress).
3. Install with Helm:
   ```bash
   helm upgrade --install link-dashboard ./helm -n monitoring --create-namespace
   ```
4. To change links: edit `helm/values.yaml` links list and run `helm upgrade` again.
