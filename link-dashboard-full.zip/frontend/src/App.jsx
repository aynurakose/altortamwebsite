import React, {useEffect, useState} from 'react'

export default function App(){
  const [links, setLinks] = useState([])
  const [error, setError] = useState(null)

  useEffect(()=>{
    const fetchConfig = async ()=>{
      try{
        const res = await fetch('/config.json', {cache: 'no-store'})
        if(!res.ok) throw new Error('config not found')
        const data = await res.json()
        setLinks(data.links || [])
      }catch(e){
        setError('Config not found')
      }
    }
    fetchConfig()
  },[])

  return (
    <div className="app">
      <header className="header">
        <h1>Link Dashboard</h1>
        <p className="muted">Click a tile to open in a new tab.</p>
        {error && <div className="error">{error}</div>}
      </header>
      <main className="grid">
        {links.map((l,i)=> (
          <a key={i} className="tile" href={l.url} target="_blank" rel="noreferrer">
            <div className="title">{l.name}</div>
            <div className="url">{l.url}</div>
          </a>
        ))}
      </main>
    </div>
  )
}
